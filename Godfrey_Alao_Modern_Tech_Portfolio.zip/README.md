# Godfrey Alao — Modern Tech Portfolio

This is a responsive, futuristic dark-theme resume/portfolio website.

## Files
- `index.html` — website content
- `styles.css` — design and responsive layout
- `script.js` — mobile menu, year, and print/save resume button

## Preview on your computer
1. Extract this ZIP file.
2. Open the folder.
3. Double-click `index.html` to preview it in a browser.
4. For best results, use an internet connection for the Google Fonts.

## Publish it free with GitHub Pages
1. Sign in to GitHub: https://github.com/
2. Create a new **public** repository named exactly `YOUR-USERNAME.github.io` (replace YOUR-USERNAME with your GitHub username).
3. Upload `index.html`, `styles.css`, and `script.js` to the repository's top level. Do not upload the ZIP itself as the only file.
4. Open the repository's **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save if that option appears.
6. Wait a few minutes and open `https://YOUR-USERNAME.github.io/`.
7. Test the link in a private/incognito browser window before sending it to employers.

If you already created a different repository, you can publish from its Settings → Pages; the address will usually be `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Before sending to employers
- Confirm the education details and add ND institution/year if you want them public.
- Add your GitHub and LinkedIn URLs when you have them.
- Keep the project description accurate to the current status of your work.
- Add phone number only if you want employers to contact you by phone.
- The “View / save resume” button opens your browser's print dialog. Choose **Save as PDF** to create a PDF copy.

## Accuracy note
This template describes you as a student seeking entry-level IT opportunities. Review every skill and project statement and remove anything you cannot confidently explain in an interview.
